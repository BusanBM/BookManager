function loginCk(obj){
	
	var mysql = require('mysql');
	var connection = mysql.createConnection({
		host:'192.168.0.151',
		user:'root',
		password:'busanit'
	});

	connection.connect();

	connection.query('use mydb');
	
	if(!obj.id.value||obj.id.value.trim().length == 0){
		alert("아이디가 입력되지 않았습니다.");
		obj.id.value = "";
		obj.id.focus();
		return false;
	}
	if(!obj.pwd.value||obj.pwd.trim().length == 0){
		alert("비밀번호를 입력해주세요.");
		obj.pwd.value = "";
		obj.pwd.focus();
		return false;
	}

	if((!obj.id.value||obj.id.value.trim().length != 0)&&(!obj.pwd.value||obj.pwd.trim().length != 0)){
		
	}
	return true;
}






