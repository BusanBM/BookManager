//function register_ok(){
//	
//}