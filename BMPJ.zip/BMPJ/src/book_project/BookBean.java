package book_project;

public class BookBean {
	private int b_no;
	private String b_title; //
	private String b_author; //
	private String b_genre; //
	private int b_price; //
	private String b_story;
	private int b_year;
	private String b_list;
	private String b_img;
	
	public String getB_title() {
		return b_title;
	}
	public void setB_title(String b_title) {
		this.b_title = b_title;
	}
	public String getB_genre() {
		return b_genre;
	}
	public void setB_genre(String b_genre) {
		this.b_genre = b_genre;
	}
	public String getB_author() {
		return b_author;
	}
	public void setB_author(String b_author) {
		this.b_author = b_author;
	}
	public String getB_img() {
		return b_img;
	}
	public void setB_img(String b_img) {
		this.b_img = b_img;
	}
	public int getB_price() {
		return b_price;
	}
	public void setB_price(int b_price) {
		this.b_price = b_price;
	}
	public int getB_year() {
		return b_year;
	}
	public void setB_year(int b_year) {
		this.b_year = b_year;
	}
	public String getB_story() {
		return b_story;
	}
	public void setB_story(String b_story) {
		this.b_story = b_story;
	}
	public String getB_list() {
		return b_list;
	}
	public void setB_list(String b_list) {
		this.b_list = b_list;
	}
	public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	
	
	
}
