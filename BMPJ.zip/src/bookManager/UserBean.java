package bookManager;

public class UserBean {
	private int cs_no;
	private String cs_id;
	private String cs_pwd;
	private String cs_name;
	private String cs_tel;
	private String cs_address;
	private String cs_email;
	private String cs_favorite;
	private String cs_grade;
	private int cs_point;
	public int getCs_no() {
		return cs_no;
	}
	public void setCs_no(int cs_no) {
		this.cs_no = cs_no;
	}
	public String getCs_id() {
		return cs_id;
	}
	public void setCs_id(String cs_id) {
		this.cs_id = cs_id;
	}
	public String getCs_pwd() {
		return cs_pwd;
	}
	public void setCs_pwd(String cs_pwd) {
		this.cs_pwd = cs_pwd;
	}
	public String getCs_name() {
		return cs_name;
	}
	public void setCs_name(String cs_name) {
		this.cs_name = cs_name;
	}
	public String getCs_tel() {
		return cs_tel;
	}
	public void setCs_tel(String cs_tel) {
		this.cs_tel = cs_tel;
	}
	public String getCs_address() {
		return cs_address;
	}
	public void setCs_address(String cs_address) {
		this.cs_address = cs_address;
	}
	public String getCs_email() {
		return cs_email;
	}
	public void setCs_email(String cs_email) {
		this.cs_email = cs_email;
	}
	public String getCs_favorite() {
		return cs_favorite;
	}
	public void setCs_favorite(String cs_favorite) {
		this.cs_favorite = cs_favorite;
	}
	public String getCs_grade() {
		return cs_grade;
	}
	public void setCs_grade(String cs_grade) {
		this.cs_grade = cs_grade;
	}
	public int getCs_point() {
		return cs_point;
	}
	public void setCs_point(int cs_point) {
		this.cs_point = cs_point;
	}
	
}
